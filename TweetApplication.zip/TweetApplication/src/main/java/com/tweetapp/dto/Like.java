package com.tweetapp.dto;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;

@DynamoDBDocument
public class Like {

	private String tweetId;
	private String username;

	public Like(String tweetId, String username) {
		super();
		this.tweetId = tweetId;
		this.username = username;
	}

	public Like() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getTweetId() {
		return tweetId;
	}

	public void setTweetId(String tweetId) {
		this.tweetId = tweetId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

}
